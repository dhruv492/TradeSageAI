"""
Module      : models.py (partial recreation — Signal & BacktestResult only)
Date        : 2026-08-07
Author      : Dhruv
Modification History:
    2026-08-07 - Recreated minimal subset needed by explainability_service.py
                 and backtesting_service.py after a fresh sandbox session.
                 Full model set (User, Holding, WatchlistItem, SentimentCache)
                 already exists in the working codebase and is unchanged;
                 only reproduced here so this module is self-contained and
                 importable on its own.
Synopsis:
    SQLAlchemy ORM definitions for the Signal and BacktestResult entities,
    matching SRS Section 5 (Data Requirements).

Naming Standard Deviation (documented, per project convention):
    Table name prefixes use underscore (tbl_Signal) rather than the hyphen
    shown in CHARUSAT v1.0 (tbl-Signal), because SQLAlchemy/most SQL engines
    do not accept hyphens in unquoted identifiers. This deviation was made
    deliberately and consistently across the whole schema, not just here.
"""

from datetime import datetime
from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

# Constants (ALL_CAPS per CHARUSAT standard)
MODEL_BASELINE = "random_forest"
MODEL_LSTM = "lstm"
DIRECTION_UP = "up"
DIRECTION_DOWN = "down"
DIRECTION_NEUTRAL = "neutral"


class User(db.Model):
    """FR-1: auth actor. Passwords stored hashed only (NFR-4)."""
    __tablename__ = "tbl_User"

    userId = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    passwordHash = db.Column(db.String(255), nullable=False)
    createdAt = db.Column(db.DateTime, default=datetime.utcnow)

    def get_id(self):
        # Flask-Login requires a string id
        return str(self.userId)


class Holding(db.Model):
    """FR-2.1-2.4: a portfolio position. P&L is computed fresh per request
    from live price, not stored, so this table only holds cost basis."""
    __tablename__ = "tbl_Holding"

    holdingId = db.Column(db.Integer, primary_key=True)
    userId = db.Column(db.Integer, db.ForeignKey("tbl_User.userId"), nullable=False)
    assetSymbol = db.Column(db.String(20), nullable=False)
    assetType = db.Column(db.String(10), nullable=False)  # 'stock' | 'crypto'
    quantity = db.Column(db.Float, nullable=False)
    buyPrice = db.Column(db.Float, nullable=False)
    buyDate = db.Column(db.Date, nullable=False)


class WatchlistItem(db.Model):
    """FR-5.1-5.2: stretch goal, unheld assets tracked for signal alerts."""
    __tablename__ = "tbl_WatchlistItem"

    watchlistId = db.Column(db.Integer, primary_key=True)
    userId = db.Column(db.Integer, db.ForeignKey("tbl_User.userId"), nullable=False)
    assetSymbol = db.Column(db.String(20), nullable=False)
    assetType = db.Column(db.String(10), nullable=False)
    dateAdded = db.Column(db.DateTime, default=datetime.utcnow)


class SentimentCache(db.Model):
    """FR-3.2 support: caches computed sentiment scores per asset/day so
    repeated signal generation calls don't re-hit NewsAPI/Reddit rate limits."""
    __tablename__ = "tbl_SentimentCache"

    cacheId = db.Column(db.Integer, primary_key=True)
    assetSymbol = db.Column(db.String(20), nullable=False)
    sourceDate = db.Column(db.Date, nullable=False)
    sentimentScore = db.Column(db.Float, nullable=False)  # VADER compound, -1..1
    sampleSize = db.Column(db.Integer, default=0)  # number of headlines/posts scored
    computedAt = db.Column(db.DateTime, default=datetime.utcnow)


class Signal(db.Model):
    """FR-3.3, FR-3.4: one row per (asset, model, generation call)."""
    __tablename__ = "tbl_Signal"

    signalId = db.Column(db.Integer, primary_key=True)
    userId = db.Column(db.Integer, db.ForeignKey("tbl_User.userId"), nullable=False)
    assetSymbol = db.Column(db.String(20), nullable=False)
    assetType = db.Column(db.String(10), nullable=False)  # 'stock' | 'crypto'
    generatedAt = db.Column(db.DateTime, default=datetime.utcnow)
    horizonDays = db.Column(db.Integer, default=3)
    modelUsed = db.Column(db.String(20), nullable=False)  # MODEL_BASELINE | MODEL_LSTM
    predictedDirection = db.Column(db.String(10), nullable=False)
    confidenceScore = db.Column(db.Float, nullable=False)
    # JSON-serialized list of {feature, contribution} — populated by
    # explainability_service.py via SHAP, previously permutation-importance.
    topContributingFeatures = db.Column(db.Text, nullable=True)
    featureSnapshot = db.Column(db.Text, nullable=True)  # JSON of raw feature row, needed for SHAP replay


class BacktestResult(db.Model):
    """FR-4.1-4.3: honesty-framework metrics only — no raw accuracy field by design."""
    __tablename__ = "tbl_BacktestResult"

    backtestId = db.Column(db.Integer, primary_key=True)
    userId = db.Column(db.Integer, db.ForeignKey("tbl_User.userId"), nullable=False)
    assetSymbol = db.Column(db.String(20), nullable=False)
    modelUsed = db.Column(db.String(20), nullable=False)
    rangeStart = db.Column(db.Date, nullable=False)
    rangeEnd = db.Column(db.Date, nullable=False)
    sharpeRatio = db.Column(db.Float, nullable=False)
    winRate = db.Column(db.Float, nullable=False)
    maxDrawdown = db.Column(db.Float, nullable=False)
    totalTrades = db.Column(db.Integer, nullable=False)
    equityCurve = db.Column(db.Text, nullable=True)  # JSON list, for dashboard charting (FR-6.2)
    runAt = db.Column(db.DateTime, default=datetime.utcnow)
