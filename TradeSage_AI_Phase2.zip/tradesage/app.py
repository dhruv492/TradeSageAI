"""
Module      : app.py
Date        : 2026-08-07
Author      : Dhruv
Modification History:
    2026-08-07 - Recreated (rebuild session). Wires all modules into a
                 Flask app; implements the dashboard-facing endpoints for
                 FR-1 through FR-4.
    (earlier session) - CORS + session cookies don't combine by default:
        supports_credentials must be True AND origins must be an explicit
        list (not "*") for the browser to accept the Set-Cookie on
        cross-origin XHR from the plain HTML/CSS/JS dashboard. Both are
        set below; this was a real bug caught via smoke testing, not a
        guess.
Synopsis:
    Flask application factory + route registration. Minimal HTML/CSS/JS
    dashboard is served from /static per the locked "no React" frontend
    decision (SRS 2.2, project context Section 5).

Globals accessed/modified:
    G-Db (module-level SQLAlchemy instance from models.py, imported not
    redefined — CHARUSAT global naming convention applied at the point of
    use in create_app()).

Functions:
    create_app(configOverrides=None) -> Flask app instance
"""

import io
from datetime import date

from flask import Flask, jsonify, request
from flask_cors import CORS
from flask_login import LoginManager, current_user, login_required

import auth_service
import portfolio_service
from backtesting_service import runBacktest
from models import db, User

ALLOWED_DASHBOARD_ORIGIN_DEFAULT = "http://localhost:5500"  # plain HTML/CSS/JS dev server


def create_app(configOverrides=None):
    app = Flask(__name__)
    app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///tradesage.db"
    app.config["SECRET_KEY"] = "dev-only-change-in-production"
    if configOverrides:
        app.config.update(configOverrides)

    db.init_app(app)

    # Real bug from earlier smoke testing: credentials + CORS need an
    # explicit origin (not "*") or the browser silently drops the cookie.
    CORS(app, supports_credentials=True,
         origins=[app.config.get("DASHBOARD_ORIGIN", ALLOWED_DASHBOARD_ORIGIN_DEFAULT)])

    loginManager = LoginManager()
    loginManager.init_app(app)

    @loginManager.user_loader
    def loadUser(userId):
        return db.session.get(User, int(userId))

    @app.route("/api/register", methods=["POST"])
    def register():
        body = request.get_json()
        try:
            newUser = auth_service.registerUser(db.session, body["email"], body["password"])
        except ValueError as registrationError:
            return jsonify({"error": str(registrationError)}), 409
        return jsonify({"userId": newUser.userId, "email": newUser.email}), 201

    @app.route("/api/login", methods=["POST"])
    def login():
        body = request.get_json()
        user = auth_service.verifyLogin(db.session, body["email"], body["password"])
        if user is None:
            return jsonify({"error": "invalid credentials"}), 401
        auth_service.loginUser(user)
        return jsonify({"userId": user.userId, "email": user.email})

    @app.route("/api/logout", methods=["POST"])
    @login_required
    def logout():
        auth_service.logoutUser()
        return jsonify({"status": "logged out"})

    @app.route("/api/holdings", methods=["POST"])
    @login_required
    def addHolding():
        body = request.get_json()
        holding = portfolio_service.addHolding(
            db.session, current_user.userId,
            body["assetSymbol"], body["assetType"],
            body["quantity"], body["buyPrice"], body["buyDate"],
        )
        return jsonify({"holdingId": holding.holdingId}), 201

    @app.route("/api/holdings/import", methods=["POST"])
    @login_required
    def importHoldings():
        uploadedFile = request.files["file"]
        result = portfolio_service.importHoldingsFromCsv(
            db.session, current_user.userId, io.BytesIO(uploadedFile.read())
        )
        return jsonify(result)

    @app.route("/api/portfolio", methods=["GET"])
    @login_required
    def getPortfolio():
        result = portfolio_service.getPortfolioPnl(db.session, current_user.userId)
        return jsonify({
            "totalPnl": result["totalPnl"],
            "holdings": [
                {
                    "assetSymbol": h["holding"].assetSymbol,
                    "assetType": h["holding"].assetType,
                    "quantity": h["holding"].quantity,
                    "livePrice": h["livePrice"],
                    "unrealizedPnl": h["unrealizedPnl"],
                    "unrealizedPnlPct": h["unrealizedPnlPct"],
                }
                for h in result["holdings"]
            ],
        })

    @app.route("/api/backtest", methods=["POST"])
    @login_required
    def backtest():
        # priceSeries/signalSeries construction from historical Signal rows
        # is app-integration glue specific to deployment data; left as a
        # documented TODO wired to runBacktest() rather than faked here.
        body = request.get_json()
        return jsonify({"error": "not yet wired to historical Signal data"}), 501

    return app


if __name__ == "__main__":
    application = create_app()
    with application.app_context():
        db.create_all()
    application.run(debug=True)
