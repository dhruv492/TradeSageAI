# TradeSage AI — CE363 Project-III (CHARUSAT)

Personal trading intelligence platform combining portfolio tracking with an
ML-driven signal engine (RandomForest baseline + LSTM, compared side by
side) for stocks and cryptocurrency. Decision-support only — not financial
advice.

## Contents

- `docs/` — Synopsis, SRS, SPMP (Phase 0 deliverables)
- `app.py` — Flask app factory + routes (auth, portfolio, dashboard)
- `models.py` — SQLAlchemy ORM (User, Holding, Signal, BacktestResult, WatchlistItem, SentimentCache)
- `auth_service.py` — FR-1: registration/login/logout
- `portfolio_service.py` — FR-2: manual entry, CSV import, live price, P&L
- `feature_pipeline.py` — FR-3.1: RSI/MACD/SMA/volume-change + direction labeling
- `sentiment_service.py` — FR-3.2: VADER + finance lexicon, cached
- `signal_engine.py` — FR-3.3 (baseline): RandomForest
- `lstm_model.py` — FR-3.3 (deep): shallow 1-layer/32-unit LSTM
- `signal_service.py` — FR-3.3–3.5 orchestrator, persists both models' signals
- `explainability_service.py` — FR-3.4: SHAP (TreeExplainer / GradientExplainer)
- `backtesting_service.py` — FR-4: Sharpe ratio, win-rate, max drawdown (Honesty Framework)
- `static/dashboard.html` — FR-6.1: minimal HTML/CSS/JS dashboard
- `smoke_test.py`, `smoke_test_full.py` — execution-based verification (not unit-test stubs; these run the real pipeline end to end)

## Setup

```bash
pip install -r requirements.txt
python app.py
```

Serves the API on `http://localhost:5000`. Open `static/dashboard.html`
directly in a browser (or via a simple dev server on port 5500 — see
`ALLOWED_DASHBOARD_ORIGIN_DEFAULT` in `app.py` if you change the port).

## Verifying the build

```bash
python smoke_test.py        # SHAP explainability + backtesting in isolation
python smoke_test_full.py   # full pipeline: auth -> portfolio -> features -> sentiment -> both models -> SHAP -> persisted signals
```

Both scripts use synthetic data and mocked price/news fetchers by design —
no live API keys are required to verify correctness. Real yfinance/Binance/
NewsAPI/PRAW clients are wired in `portfolio_service.py` and
`sentiment_service.py`'s default fetchers for actual deployment.

## Status

Phase 0 (docs) — complete.
Phase 1 (MVP core) — complete.
Phase 2 (ML depth: sentiment, LSTM, SHAP, backtesting) — complete.
Phase 3 (Watchlist/Alerts, dashboard feedback loop, Admin panel) — not started, stretch scope per SPMP.

## Known deviations (documented, not oversights)

- DB table prefixes use `tbl_` (underscore) instead of CHARUSAT v1.0's
  `tbl-` (hyphen), because SQL engines reject hyphens in unquoted
  identifiers. Documented in `models.py`'s header.
- SHAP's LSTM explainer is `GradientExplainer`, not `DeepExplainer` —
  `DeepExplainer` has no built-in rule for `nn.LSTM` and failed its own
  additivity check during smoke testing. Documented in
  `explainability_service.py`'s header.
